module.exports = {
    links: [
        {
            source: 1,
            target: 2
        },
        {
            source: 2,
            target: 3
        },
        {
            source: 1,
            target: 3
        },
        {
            source: 3,
            target: 4
        }
    ],
    nodes: [
        {
            id: 1,
            nodeType: 'fo',
            nodeName: 'A',
            nodeDescription: '',
            nodeConfig: {}
        },
        {
            id: 2,
            nodeType: 'do',
            nodeName: 'B',
            nodeDescription: '',
            nodeConfig: {}
        },
        {
            id: 3,
            nodeType: 'fo',
            nodeName: 'C',
            nodeDescription: '',
            nodeConfig: {}
        },
        {
            id: 4,
            nodeType: 'fo',
            nodeName: 'D',
            nodeDescription: '',
            nodeConfig: {}
        }
    ]
};
