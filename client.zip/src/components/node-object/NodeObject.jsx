// React base
import React from 'react';

// Styles
import './styles/node-object.css';

// Global Vars
const ICON_PATH = './img/';

const ICON_TYPES = {
    FO: ICON_PATH + 'man.svg',
    DO: ICON_PATH + 'girl.svg'
};

/**
 * Component that renders a node objects type, along with icons
 * representing the respective content (e.g. code or data)
 */
function NodeObject({ obj }) {
            
    return (
        <div className={`flex-container obj-node ${obj.nodeType}`}>
            <div className="name">{obj.nodeName}</div>
            
            <div className="flex-container fill-space flex-container-row">
                <div className="fill-space">
                    <div className="icon" />
                    
                </div>
            </div>
        </div>
    );
}

export default NodeObject;
