// React base
import React, { Component } from 'react';
import { Link } from 'react-router-dom';

// Builder components
import { Graph } from '../../components';
import graphDefaultConfig from '../../components/node-object/node-object.config';

// Utils
import utils from './utils'
import reactD3GraphUtils from '../../components/utils';

// Styles
import './Builder.css';
import logo from '../../img/ubs-logo-white.svg';

// Test data
const testData = utils.loadDataset();

// Main class
class Builder extends Component {

  // Constructor
  constructor(props) {
        super(props);
        
        // Settings
        const { config: configOverride, data, fullscreen } = testData;
        const config = Object.assign(graphDefaultConfig, configOverride);
        const schemaProps = utils.generateFormSchema(config, '', {});
        
        // Schema
        const schema = {
            type: 'object',
            properties: schemaProps
        };
        const uiSchema = {
            height: { 'ui:readonly': 'true' },
            width: { 'ui:readonly': 'true' }
        };
        this.uiSchema = uiSchema;
        
        // State
        this.state = {
            config,
            generatedConfig: {},
            schema,
            data,
            fullscreen
        };
    }
    
    /**
     * Event Handler: (Left) Click on Graph canvas
     * #DISABLED for now
     */
    //onClickGraph = () => console.info(`Clicked the graph`);
    onClickGraph = undefined
    
    /**
     * Event Handler: (Left) Click on a Node
     * This sets the focusedNodeId to ID of clicked node
     * and thus triggers the focusAnimation, i.e. moving the 
     * clicked node to the center of the Graph canvas
     */
    onClickNode = id => {
        //!this.state.config.collapsible && window.alert(`Clicked node ${id}`);
        this.setState({
           data: {
               ...this.state.data,
               focusedNodeId: this.state.data.focusedNodeId !== id ? id : null
           }
        });
    };
    
    /**
     * Event Handler: (Right) Click on a Node
     * #DISABLED for now
     */
    /*onRightClickNode = (event, id) => {
        event.preventDefault();
    };*/
    onRightClickNode = undefined
    
    /**
     * Event Handler: (Left) Click on a Link
     * #DISABLED for now
     */
    //onClickLink = (source, target) => window.alert(`Clicked link between ${source} and ${target}`);
    onClickLink = undefined
    
    /**
     * Event Handler: (Right) Click on a Link
     * #DISABLED for now
     */
    /*onRightClickLink = (event, source, target) => {
        event.preventDefault();
    };*/
    onRightClickLink = undefined
    
    /**
     * Event Handler: Mouse over a Node
     * #DISABLED for now
     */
    //onMouseOverNode = id => console.info(`Do something when mouse is over node (${id})`);
    onMouseOverNode = undefined
    
    /**
     * Event Handler: Mouse out of a Node
     * #DISABLED for now
     */
    //onMouseOutNode = id => console.info(`Do something when mouse is out of node (${id})`);
    onMouseOutNode = undefined
    
    /**
     * Event Handler: Mouse over a Link
     * #DISABLED for now
     */
    /*onMouseOverLink = (source, target) =>
        console.info(`Do something when mouse is over link between ${source} and ${target}`);*/
    onMouseOverLink = undefined
    
    /**
     * Event Handler: Mouse out of a Link
     * #DISABLED for now
     */
    /*onMouseOutLink = (source, target) =>
        console.info(`Do something when mouse is out of link between ${source} and ${target}`);*/
    onMouseOutLink = undefined
    
    /**
     * Event Handler: Toggle fullscreen
     * #DISABLED - not needed anymore
     */
    /*onToggleFullScreen = () => {
        const fullscreen = !this.state.fullscreen;

        this.setState({ fullscreen });
    };*/
    onToggleFullScreen = undefined
    
    /**
     * PASS-THROUGH-FCN: restart graph simulation
     * #DISABLED for now
     */
    //restartGraphSimulation = () => this.refs.graph.restartSimulation();
    restartGraphSimulation = undefined
    
    /**
     * PASS-THROUGH-FCN: pause graph simulation
     * #DISABLED for now
     */
    //pauseGraphSimulation = () => this.refs.graph.pauseSimulation();
    pauseGraphSimulation = undefined
    
    /**
     * PASS-THROUGH-FCN: reset node positions
     * #DISABLED for now
     */
    //resetNodesPositions = () => this.refs.graph.resetNodesPositions();
    resetNodesPositions = undefined
    
    
    
    
    
    
    
    
    
    
    
    /**
     * This function decorates nodes and links with positions. The motivation
     * for this function is to set `config.staticGraph` to true on the first render
     * call, and to get nodes and links statically set to their initial positions.
     * @param  {Object} nodes nodes and links with minimalist structure.
     * @return {Object} the graph where now nodes containing (x,y) coords.
     */
    decorateGraphNodesWithInitialPositioning = nodes => {
        return nodes.map(n =>
            Object.assign({}, n, {
                x: n.x || Math.floor(Math.random() * 500),
                y: n.y || Math.floor(Math.random() * 500)
            })
        );
    };
    
    // Render builder
    render() {
        // This does not happens in this sandbox scenario running time, but if we set staticGraph config
        // to true in the constructor we will provide nodes with initial positions
        const data = {
            nodes: this.decorateGraphNodesWithInitialPositioning(this.state.data.nodes),
            links: this.state.data.links,
            focusedNodeId: this.state.data.focusedNodeId
        };
        
        // Properties of graph
        const graphProps = {
            id: 'graph',
            data,
            config: this.state.config,
            onClickNode: this.onClickNode,
            onRightClickNode: this.onRightClickNode,
            onClickGraph: this.onClickGraph,
            onClickLink: this.onClickLink,
            onRightClickLink: this.onRightClickLink,
            onMouseOverNode: this.onMouseOverNode,
            onMouseOutNode: this.onMouseOutNode,
            onMouseOverLink: this.onMouseOverLink,
            onMouseOutLink: this.onMouseOutLink
        };
        
        // Fullscreen by default
        graphProps.config = Object.assign({}, graphProps.config, {
            height: window.innerHeight,
            width: window.innerWidth
        });
        
        // Publish builder
        if (this.state.fullscreen) {
            return (
                <div>
                    <Graph ref="graph" {...graphProps} />
                </div>
            );
        } else {
            return (
                <div className="container">
                    <div className="TopBar">
                        <Link to='/'>
                            <img src={logo} className="TopBarLogo" alt="logo" />
                        </Link>
                        <div>Analytics Pipeline Builder</div>
                    </div>
                    <div className="RightBar">
                        <h3>Node X</h3>
                    </div>
                    <div className="container_graph">
                        <Graph ref="graph" {...graphProps} />
                    </div>
                </div>
            );
        }
    }
  
}

export default Builder;
